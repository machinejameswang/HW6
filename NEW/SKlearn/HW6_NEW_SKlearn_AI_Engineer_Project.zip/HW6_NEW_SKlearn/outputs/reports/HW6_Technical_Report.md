# HW6 NEW SKlearn - Full AI Engineer Project Report

## Executive Summary

This project upgrades the startup profit prediction task into a complete AI engineer-style machine learning project.

The same dataset is used for multiple machine learning tasks:

1. Data preprocessing
2. Regression prediction
3. Profit-level classification
4. PCA dimensionality reduction
5. KMeans clustering
6. Model benchmarking
7. Joblib deployment artifacts
8. Streamlit application

## Dataset

| Item | Value |
|---|---:|
| Rows | 1000 |
| Missing values | 0 |
| Numeric features | R&D Spend, Administration, Marketing Spend |
| Categorical feature | State |
| Regression target | Profit |
| Classification target | Profit_Level |

## Regression Results

| Model             |      MAE |     RMSE |       R2 |   CV_R2_Mean |
|:------------------|---------:|---------:|---------:|-------------:|
| KNN Regressor     |  3187.02 |  4242.8  | 0.989017 |     0.987992 |
| Random Forest     |  3605.08 |  5177.85 | 0.983642 |     0.983399 |
| Gradient Boosting |  4191.04 |  5732.36 | 0.979951 |     0.97876  |
| Decision Tree     |  4062.16 |  6135.25 | 0.977033 |     0.976985 |
| Linear Regression |  7737.05 | 10545.4  | 0.932149 |     0.93589  |
| LASSO Regression  |  7737.05 | 10545.4  | 0.932149 |     0.935891 |
| Ridge Regression  |  7739.06 | 10548.3  | 0.932112 |     0.93589  |
| Elastic Net       |  7997.11 | 10870    | 0.927907 |     0.932798 |
| SVR               | 24950    | 33932.4  | 0.297477 |     0.274968 |

## Classification Results

| Model                    |   Accuracy |   F1_Macro |
|:-------------------------|-----------:|-----------:|
| Logistic Regression      |      0.915 |   0.915582 |
| Random Forest Classifier |      0.895 |   0.895799 |

## PCA and Clustering

| Item | Value |
|---|---:|
| PCA components | 2 |
| Explained variance | 0.9231 |
| KMeans clusters | 3 |
| Silhouette score | 0.3976 |

## Feature Importance

| Feature         |   Importance |
|:----------------|-------------:|
| R&D Spend       |   0.899785   |
| Marketing Spend |   0.0877185  |
| Administration  |   0.00738535 |
| State_New York  |   0.0033054  |
| State_Florida   |   0.00180577 |

## AI Engineering Conclusion

The project is suitable as a complete sklearn homework and portfolio project. It demonstrates how a regression dataset can be extended into regression, classification, clustering, and dimensionality reduction tasks.

The final deployment design uses:

```text
Input startup spending data
    -> preprocessing pipeline
    -> best regression model
    -> predicted Profit
```

and

```text
Input startup spending data
    -> classifier pipeline
    -> Profit_Level
```
