@echo off
cd /d D:\AI人工智慧\Antigravity\HW6\NEW\SKlearn
pip install -r requirements.txt
python src\hw6_full_pipeline.py
streamlit run src\streamlit_app.py
