# HW6 NEW SKlearn - Full AI Engineer Project

This project is designed for:

- Data preprocessing
- Regression prediction
- Classification
- PCA dimensionality reduction
- KMeans clustering
- Regression model benchmark
- Deployment with Streamlit

## Dataset

`data/50_Startups_augmented_1000.csv`

Rows: 1000

## Best Regression Model

KNN Regressor

## Metrics

- R2: 0.9890
- RMSE: 4242.80
- MAE: 3187.02

## Run

```bash
cd D:\AI人工智慧\Antigravity\HW6\NEW\SKlearn
pip install -r requirements.txt
python src/hw6_full_pipeline.py
streamlit run src/streamlit_app.py
```

## Outputs

- `outputs/regression_model_benchmark.csv`
- `outputs/classification_model_benchmark.csv`
- `outputs/HW6_processed_dataset.csv`
- `outputs/models/best_regression_pipeline.joblib`
- `outputs/models/profit_level_classifier_pipeline.joblib`
- `outputs/reports/HW6_Technical_Report.pdf`
- `outputs/reports/HW6_one_page_infographic.png`
