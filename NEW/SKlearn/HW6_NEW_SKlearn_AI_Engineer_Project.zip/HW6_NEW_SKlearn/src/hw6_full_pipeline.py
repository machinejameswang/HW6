"""
HW6 NEW SKlearn - Full AI Engineer ML Project

Tasks:
1. Data preprocessing
2. Regression prediction
3. Classification
4. PCA dimensionality reduction
5. KMeans clustering
6. Model benchmark
7. Deployment artifacts
"""

from pathlib import Path
import math
import joblib
import pandas as pd
import numpy as np

from sklearn.model_selection import train_test_split, KFold, cross_val_score
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LinearRegression, Ridge, Lasso, ElasticNet, LogisticRegression
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor, RandomForestClassifier
from sklearn.tree import DecisionTreeRegressor
from sklearn.neighbors import KNeighborsRegressor
from sklearn.svm import SVR
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score, accuracy_score, f1_score, silhouette_score


ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "50_Startups_augmented_1000.csv"
OUTPUTS = ROOT / "outputs"
MODELS = OUTPUTS / "models"
FIGURES = OUTPUTS / "figures"

for d in [OUTPUTS, MODELS, FIGURES]:
    d.mkdir(parents=True, exist_ok=True)


def build_preprocessor(num_cols, cat_cols):
    return ColumnTransformer([
        ("num", StandardScaler(), num_cols),
        ("cat", OneHotEncoder(drop="first", handle_unknown="ignore"), cat_cols)
    ])


def main():
    df = pd.read_csv(DATA_PATH)

    target = "Profit"
    num_cols = ["R&D Spend", "Administration", "Marketing Spend"]
    cat_cols = ["State"]

    df["Profit_Level"] = pd.qcut(df[target], q=3, labels=["Low", "Medium", "High"])

    # PCA + clustering
    scaled_num = StandardScaler().fit_transform(df[num_cols])
    pca = PCA(n_components=2, random_state=42)
    pca_xy = pca.fit_transform(scaled_num)
    df["PCA1"] = pca_xy[:, 0]
    df["PCA2"] = pca_xy[:, 1]

    kmeans = KMeans(n_clusters=3, random_state=42, n_init=10)
    df["Cluster"] = kmeans.fit_predict(scaled_num)
    print("KMeans silhouette:", silhouette_score(scaled_num, df["Cluster"]))

    df.to_csv(OUTPUTS / "HW6_processed_dataset.csv", index=False)

    X = df[num_cols + cat_cols]
    y = df[target]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=.2, random_state=42)

    preprocessor = build_preprocessor(num_cols, cat_cols)

    reg_models = {
        "Linear Regression": LinearRegression(),
        "Ridge Regression": Ridge(alpha=1.0),
        "LASSO Regression": Lasso(alpha=0.1, max_iter=20000),
        "Elastic Net": ElasticNet(alpha=0.1, l1_ratio=0.5, max_iter=20000),
        "Decision Tree": DecisionTreeRegressor(random_state=42, max_depth=6),
        "Random Forest": RandomForestRegressor(n_estimators=300, random_state=42),
        "Gradient Boosting": GradientBoostingRegressor(random_state=42),
        "KNN Regressor": KNeighborsRegressor(n_neighbors=7),
        "SVR": SVR(kernel="rbf", C=100, epsilon=0.1)
    }

    rows = []
    trained = {}
    cv = KFold(n_splits=5, shuffle=True, random_state=42)

    for name, model in reg_models.items():
        pipe = Pipeline([("preprocessor", preprocessor), ("model", model)])
        pipe.fit(X_train, y_train)
        pred = pipe.predict(X_test)
        cv_scores = cross_val_score(pipe, X, y, cv=cv, scoring="r2")
        rows.append({
            "Model": name,
            "MAE": mean_absolute_error(y_test, pred),
            "RMSE": math.sqrt(mean_squared_error(y_test, pred)),
            "R2": r2_score(y_test, pred),
            "CV_R2_Mean": cv_scores.mean()
        })
        trained[name] = pipe

    reg_results = pd.DataFrame(rows).sort_values("RMSE")
    reg_results.to_csv(OUTPUTS / "regression_model_benchmark.csv", index=False)
    best_name = reg_results.iloc[0]["Model"]
    joblib.dump(trained[best_name], MODELS / "best_regression_pipeline.joblib")

    # Classification
    Xc = df[num_cols + cat_cols]
    yc = df["Profit_Level"].astype(str)
    Xc_train, Xc_test, yc_train, yc_test = train_test_split(Xc, yc, test_size=.2, random_state=42, stratify=yc)

    clf_models = {
        "Logistic Regression": LogisticRegression(max_iter=2000),
        "Random Forest Classifier": RandomForestClassifier(n_estimators=300, random_state=42)
    }

    clf_rows = []
    for name, model in clf_models.items():
        pipe = Pipeline([("preprocessor", preprocessor), ("model", model)])
        pipe.fit(Xc_train, yc_train)
        pred = pipe.predict(Xc_test)
        clf_rows.append({
            "Model": name,
            "Accuracy": accuracy_score(yc_test, pred),
            "F1_Macro": f1_score(yc_test, pred, average="macro")
        })
        if name == "Random Forest Classifier":
            joblib.dump(pipe, MODELS / "profit_level_classifier_pipeline.joblib")

    pd.DataFrame(clf_rows).sort_values("F1_Macro", ascending=False).to_csv(
        OUTPUTS / "classification_model_benchmark.csv", index=False
    )

    print("Best regression model:", best_name)
    print(reg_results.head())


if __name__ == "__main__":
    main()
