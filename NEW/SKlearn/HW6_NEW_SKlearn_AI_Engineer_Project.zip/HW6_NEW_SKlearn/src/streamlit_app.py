import streamlit as st
import pandas as pd
import joblib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MODEL_PATH = ROOT / "outputs" / "models" / "best_regression_pipeline.joblib"
CLF_PATH = ROOT / "outputs" / "models" / "profit_level_classifier_pipeline.joblib"

st.set_page_config(page_title="HW6 Startup Profit ML App", layout="wide")
st.title("HW6 Startup Profit Prediction - SKlearn ML App")

reg_model = joblib.load(MODEL_PATH)
clf_model = joblib.load(CLF_PATH)

col1, col2 = st.columns(2)
with col1:
    rd = st.number_input("R&D Spend", min_value=0.0, value=100000.0)
    admin = st.number_input("Administration", min_value=0.0, value=120000.0)
with col2:
    marketing = st.number_input("Marketing Spend", min_value=0.0, value=250000.0)
    state = st.selectbox("State", ["California", "Florida", "New York"])

x = pd.DataFrame([{
    "R&D Spend": rd,
    "Administration": admin,
    "Marketing Spend": marketing,
    "State": state
}])

if st.button("Predict"):
    profit = reg_model.predict(x)[0]
    level = clf_model.predict(x)[0]
    st.metric("Predicted Profit", f"${profit:,.2f}")
    st.metric("Profit Level", level)
